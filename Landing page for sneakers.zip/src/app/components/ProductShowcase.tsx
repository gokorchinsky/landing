import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Heart, ShoppingCart } from "lucide-react";

const products = [
  {
    id: 1,
    name: "AirFlow Pro",
    price: "3 999",
    image: "https://images.unsplash.com/photo-1765175095955-d4c8b4b45a5d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb2Rlcm4lMjBzbmVha2VycyUyMHdoaXRlJTIwYmFja2dyb3VuZHxlbnwxfHx8fDE3NzA2MjEyNjl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Бігові",
    colors: ["#000000", "#FFFFFF", "#FF0000"],
  },
  {
    id: 2,
    name: "Urban Runner",
    price: "2 799",
    image: "https://images.unsplash.com/photo-1719523677291-a395426c1a87?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydW5uaW5nJTIwc2hvZXMlMjBwcm9kdWN0fGVufDF8fHx8MTc3MDYxODUwNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Спортивні",
    colors: ["#0000FF", "#00FF00", "#FFFF00"],
  },
  {
    id: 3,
    name: "Street Style X",
    price: "3 299",
    image: "https://images.unsplash.com/photo-1756707235708-01aa79b8bf51?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzcG9ydHMlMjBzbmVha2VycyUyMGxpZmVzdHlsZXxlbnwxfHx8fDE3NzA2NzIwNzB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Лайфстайл",
    colors: ["#FFA500", "#800080", "#008080"],
  },
  {
    id: 4,
    name: "Performance Elite",
    price: "4 499",
    image: "https://images.unsplash.com/photo-1758665630748-08141996c144?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxhdGhsZXRpYyUyMHNob2VzJTIwY29sbGVjdGlvbnxlbnwxfHx8fDE3NzA2NzIwNzF8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
    category: "Преміум",
    colors: ["#000000", "#C0C0C0", "#FFD700"],
  },
];

export function ProductShowcase() {
  return (
    <section id="products" className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-4">
            Популярні моделі
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Виберіть кросівки, які підкреслять ваш унікальний стиль
          </p>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {products.map((product) => (
            <div
              key={product.id}
              className="group relative bg-white rounded-2xl overflow-hidden border border-gray-200 hover:shadow-2xl transition-all duration-300"
            >
              {/* Image Container */}
              <div className="relative aspect-square bg-gray-50 overflow-hidden">
                <ImageWithFallback
                  src={product.image}
                  alt={product.name}
                  className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500"
                />
                
                {/* Wishlist Button */}
                <button className="absolute top-4 right-4 p-2 bg-white rounded-full shadow-lg hover:bg-red-50 transition-colors">
                  <Heart className="w-5 h-5 text-gray-700 hover:text-red-500" />
                </button>

                {/* Category Badge */}
                <div className="absolute top-4 left-4 bg-black text-white px-3 py-1 rounded-full text-sm">
                  {product.category}
                </div>
              </div>

              {/* Product Info */}
              <div className="p-6">
                <h3 className="text-xl text-gray-900 mb-2">{product.name}</h3>
                
                {/* Color Options */}
                <div className="flex gap-2 mb-4">
                  {product.colors.map((color, index) => (
                    <button
                      key={index}
                      className="w-6 h-6 rounded-full border-2 border-gray-300 hover:border-gray-900 transition-colors"
                      style={{ backgroundColor: color }}
                      aria-label={`Color option ${index + 1}`}
                    />
                  ))}
                </div>

                {/* Price & CTA */}
                <div className="flex items-center justify-between">
                  <div>
                    <span className="text-2xl text-gray-900">{product.price}</span>
                    <span className="text-gray-600"> грн</span>
                  </div>
                  <button className="bg-black text-white p-3 rounded-full hover:bg-gray-800 transition-colors">
                    <ShoppingCart className="w-5 h-5" />
                  </button>
                </div>
              </div>

              {/* Hover Overlay */}
              <div className="absolute inset-0 bg-black/0 group-hover:bg-black/5 transition-colors pointer-events-none" />
            </div>
          ))}
        </div>

        {/* View All Button */}
        <div className="text-center mt-12">
          <button className="bg-gray-100 text-gray-900 px-8 py-4 rounded-full hover:bg-gray-200 transition-colors">
            Переглянути всі моделі
          </button>
        </div>
      </div>
    </section>
  );
}
