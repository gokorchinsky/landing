import { Truck, Shield, Sparkles, Clock } from "lucide-react";

const features = [
  {
    icon: Truck,
    title: "Безкоштовна доставка",
    description: "Доставка по всій Україні від 2000 грн",
  },
  {
    icon: Shield,
    title: "Гарантія якості",
    description: "Офіційна гарантія на всі моделі",
  },
  {
    icon: Sparkles,
    title: "Ексклюзивні моделі",
    description: "Унікальні кросівки від провідних брендів",
  },
  {
    icon: Clock,
    title: "Швидка обробка",
    description: "Відправка замовлення протягом 24 годин",
  },
];

export function Features() {
  return (
    <section id="features" className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl text-gray-900 mb-4">
            Чому обирають нас?
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Ми пропонуємо найкращі умови для наших клієнтів
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="bg-white p-8 rounded-2xl text-center hover:shadow-xl transition-shadow duration-300 border border-gray-200"
              >
                <div className="inline-flex items-center justify-center w-16 h-16 bg-gradient-to-br from-blue-500 to-purple-600 rounded-2xl mb-6">
                  <Icon className="w-8 h-8 text-white" />
                </div>
                <h3 className="text-xl text-gray-900 mb-3">
                  {feature.title}
                </h3>
                <p className="text-gray-600">
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>

        {/* Additional Info */}
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-3xl p-12 text-center text-white">
          <h3 className="text-3xl md:text-4xl mb-4">
            Приєднуйтесь до нашої спільноти
          </h3>
          <p className="text-xl mb-8 opacity-90">
            Отримуйте ексклюзивні знижки та першими дізнавайтесь про нові надходження
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
            <input
              type="email"
              placeholder="Ваша електронна адреса"
              className="px-6 py-4 rounded-full text-gray-900 flex-1 focus:outline-none focus:ring-2 focus:ring-white"
            />
            <button className="bg-black text-white px-8 py-4 rounded-full hover:bg-gray-800 transition-colors whitespace-nowrap">
              Підписатись
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
