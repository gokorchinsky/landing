import { ShoppingCart, Menu } from "lucide-react";
import { useState } from "react";

export function Header() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  return (
    <header className="fixed top-0 left-0 right-0 bg-white/95 backdrop-blur-sm z-50 border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <h1 className="text-2xl font-bold text-gray-900">SneakerPro</h1>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex space-x-8">
            <a href="#home" className="text-gray-700 hover:text-gray-900 transition-colors">
              Головна
            </a>
            <a href="#products" className="text-gray-700 hover:text-gray-900 transition-colors">
              Продукти
            </a>
            <a href="#features" className="text-gray-700 hover:text-gray-900 transition-colors">
              Особливості
            </a>
            <a href="#contact" className="text-gray-700 hover:text-gray-900 transition-colors">
              Контакти
            </a>
          </nav>

          {/* Cart & Mobile Menu */}
          <div className="flex items-center gap-4">
            <button className="relative p-2 text-gray-700 hover:text-gray-900 transition-colors">
              <ShoppingCart className="w-6 h-6" />
              <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                0
              </span>
            </button>
            
            <button 
              className="md:hidden p-2 text-gray-700"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              <Menu className="w-6 h-6" />
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <nav className="md:hidden py-4 border-t border-gray-200">
            <div className="flex flex-col space-y-4">
              <a href="#home" className="text-gray-700 hover:text-gray-900">
                Головна
              </a>
              <a href="#products" className="text-gray-700 hover:text-gray-900">
                Продукти
              </a>
              <a href="#features" className="text-gray-700 hover:text-gray-900">
                Особливості
              </a>
              <a href="#contact" className="text-gray-700 hover:text-gray-900">
                Контакти
              </a>
            </div>
          </nav>
        )}
      </div>
    </header>
  );
}
