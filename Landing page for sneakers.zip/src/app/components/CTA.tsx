import { ImageWithFallback } from "./figma/ImageWithFallback";
import { Star } from "lucide-react";

export function CTA() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-black rounded-3xl overflow-hidden">
          <div className="grid md:grid-cols-2 gap-0">
            {/* Left Content */}
            <div className="p-12 lg:p-16 flex flex-col justify-center">
              <div className="space-y-6">
                <div className="flex items-center gap-1 text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-6 h-6 fill-current" />
                  ))}
                </div>
                
                <h2 className="text-4xl md:text-5xl text-white">
                  Знижка -25% на першу покупку
                </h2>
                
                <p className="text-xl text-gray-300">
                  Зареєструйтесь зараз і отримайте спеціальну пропозицію на будь-які кросівки з нашої колекції
                </p>

                <div className="space-y-4">
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Доступ до ексклюзивних моделей</span>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Ранній доступ до розпродажів</span>
                  </div>
                  <div className="flex items-center gap-3 text-white">
                    <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                    <span>Безкоштовна доставка на все</span>
                  </div>
                </div>

                <button className="bg-white text-black px-8 py-4 rounded-full hover:bg-gray-100 transition-colors w-full sm:w-auto mt-4">
                  Отримати знижку
                </button>
              </div>
            </div>

            {/* Right Image */}
            <div className="relative h-full min-h-[400px]">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1719523677291-a395426c1a87?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxydW5uaW5nJTIwc2hvZXMlMjBwcm9kdWN0fGVufDF8fHx8MTc3MDYxODUwNXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Special Offer"
                className="absolute inset-0 w-full h-full object-cover"
              />
              <div className="absolute top-8 right-8 bg-red-500 text-white px-6 py-3 rounded-full text-xl">
                -25%
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
